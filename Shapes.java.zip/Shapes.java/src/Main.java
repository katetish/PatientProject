// Press ⇧ twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
import java.util.*;
import java.awt.Color;


public class Shapes {
    // 2 method calls for Task 1
    public static void main(String[] args) {
        Turtle t = new Turtle();                              //create new turtle t
        drawHexagon(t, 50);                // Call the drawHexagon method, passing in the Turtle object and a side length of 50
        t.left(90);                       // move the turtle to the left, so the figures don't overlap
        drawNgon (t, 3, 50);
        randomRegularShapes(t, new Random(), 5, 100);
        drawGrid(t, 3, 4, 100, 50);
        drawOrder(t, 100, 50);

    }

    public static void drawHexagon(Turtle t, int sideLength) { //first method call
        for (int i = 0; i < 6; i++) {
            t.forward(sideLength);            //move the turtle forward by identified sideLenght
            t.right(60);                      //turn the turlte right by 60°
        }
    }

    public static void drawNgon(Turtle t, int numSides, int sideLength) {  //second method call
        for (int side = 0; side < numSides; side++) {   //for loop that draw an equilateral triangle
            t.forward(sideLength);            //move the turtle forward by identified sideLenght
            t.right(360/numSides);           // turn the turtle to the right by 360/6 degrees (60 degrees)
        }
    }

    // 2 method calls for Task 2
    //Option 1: Random Regular Shapes
    public static void randomRegularShapes(Turtle t, Random rand, int numShapes, int maxSize) {
        int sideLength = rand.nextInt(maxSize) + 1;  //set a reandom side length
        int angle = 360/5;
        for (int i = 0; i < numShapes; i++) {
            drawNgon (t, 5, sideLength);            //call drawNgon method to draw the pentagon
            t.forward(sideLength);                  //move the pentagon to create a spiral effect
            t.right(angle);
            t.right(sideLength * 70 + 70);   // move the turtle forward by the side length plus times 20 plus 20
        }
    }
    //Option 2:Draw Grid
    public static void drawGrid(Turtle t, int rows, int columns, int shift, int sideLength) {
        for (int i = 0; i < rows; i++) {
            t.setPosition(0, i * shift);
            for (int j = 0; j < columns; j++){
                drawNgon (t, 5, sideLength);            //call drawNgon method to draw the pentagon
                t.forward(shift); // move the turtle forward by shift + 20 to increase separation between shapes
            }
        }
    }

    // Task 3 - Method which draws the order of the Maltese knights

    public static void drawOrder(Turtle t, int triangleHeight, int triangleWidth) {
        for (int i = 0; i < 3; i++) {
            // Calculate the number of triangles and the space between them
            int numTriangles = i + 2;
            int spaceBetween = (300 - numTriangles * triangleWidth) / (numTriangles + 1); // loop to draw each row of triangles
            for (int j = 0; j < numTriangles; j++) {
                for (int k = 0; k < 3; k++) {       //draw the triangle
                    t.forward(triangleHeight);
                    t.right(120);
                }
                t.left(90);       //move to the next triangle
            }
        }
    }
}
