// Kate Tishkova
// 05/17/2023
// CSE 121 Section AD
// TA: James Try
//
// Programming Assignment #2


import java.util.*;

public class Main {
    public static final int HOSPITAL_ZIP = 12345;
    public static int patientCount = 0;
    public static int maxScore = 0;

    public static void main(String[] args) {
        WelcomeMessage();
        Scanner Data = new Scanner(System.in);
        String Name;
        while (true) {
            Name = GetPatientName(Data);
            if (Name.equals("quit")) {
                PrintStats(patientCount, maxScore);
                return;
            }
            int Score = getScore(Data);
            PrintPriority(Name, Score);
            System.out.println();
            System.out.println("Thank you for using our system!");
            System.out.println("We hope we have helped you do your best!");
            System.out.println();
        }
    }

    public static void WelcomeMessage() {
        System.out.println("Hello! We value you and your time, so we will help");
        System.out.println("you prioritize which patients to see next!");
        System.out.println("Please answer the following questions about the next patient so");
        System.out.println("we can help you do your best work :)");
        System.out.println();
    }

    public static String GetPatientName(Scanner obj) {
        String PatName = " ";
        String Intro = "Please enter the next patient's name or \"quit\" to end the program.";
        String PName = "Patient's name: ";
        System.out.println(Intro);
        System.out.print(PName);
        PatName = obj.next();

        return PatName;
    }

    public static int getScore(Scanner obj) {
        int Score = 100;
        int Age = 0;
        int zipCode = 0;
        String insInfo = " ";
        int PainLvl = 0;
        double Temp = 0;
        String StrAge = "Patient age: ";
        System.out.print(StrAge);


        //try {                                      //irrelevant code(?)
        Age = obj.nextInt();
            /*
        } catch (InputMismatchException e) {
            System.out.print("Invalid age, enter valid age: ");
            obj.next(); // Consume the invalid input
            Age = obj.nextInt();
        }
        */


        String StrzipCode = "Patient zip code: ";
        System.out.print(StrzipCode);

        zipCode = obj.nextInt();
        boolean validZip = validZipCode(zipCode);
        while (!validZip) {
            System.out.print("Invalid zip code, enter valid zip code: ");
            zipCode = obj.nextInt();
            validZip = validZipCode(zipCode);
        }

        String StrinsInfo = "Is our hospital \"in network\" for the patient's insurance? ";
        System.out.print(StrinsInfo);
        insInfo = obj.next();

        boolean validPainLvl = validPainLevel(PainLvl);

        String StrPainLvl = "Patient pain level (1-10): ";
        System.out.print(StrPainLvl);
        PainLvl = obj.nextInt();
        while (!validPainLevel(PainLvl)) {
            System.out.print("Invalid pain level, enter valid pain level (1-10): ");
            PainLvl = obj.nextInt();
        }

        String StrTemp = "Patient temperature (in degrees Fahrenheit): ";
        System.out.print(StrTemp);
        Temp = obj.nextDouble();

        int patientZipCodeFirstDigit = 0;
        Score = calculateScore(Age, zipCode, patientZipCodeFirstDigit, insInfo, PainLvl, Temp);

        patientCount++;
        maxScore = Math.max(maxScore, Score);

        return Score;
    }

    public static int calculateScore(int Age, int zipCode, int patientZipCodeFirstDigit, String insInfo, int PainLvl, double Temp) {
        int MyScore = 100;

        // Check age
        if (Age < 12 || Age >= 75) {
            MyScore += 50;
        }

        // Check zip code
        int HOSPITAL_ZIPFirstDigit = HOSPITAL_ZIP / 10000;
        int patientZipFirstDigit = zipCode / 10000;
        int patientZipCodeSecondDigit = (zipCode / 1000) % 10;
        int HOSPITAL_ZIPSecondDigit = (HOSPITAL_ZIP / 1000) % 10;

        // Check Zip Code similarity
        if (patientZipFirstDigit == HOSPITAL_ZIPFirstDigit && patientZipCodeSecondDigit == HOSPITAL_ZIPSecondDigit) {
            MyScore += 25;
            MyScore += 15;
        } else if (patientZipFirstDigit == HOSPITAL_ZIPFirstDigit) {
            MyScore += 25;
        }

        // Check insurance information
        if (insInfo.equals("yes") || insInfo.equals("y")) {
            MyScore += 50;
        }


        // Calculate pain score
        MyScore += PainLvl * 10;

        // Check temperature
        if (Temp > 99.5) {
            MyScore += 8;
        }

        return MyScore;
    }

    public static void PrintPriority(String Name, int Score) {
        String priorityMessage = "We have found patient " + Name + " to have a priority score of: " + Score;

        if (Score < 163) {
            priorityMessage += "\nWe have determined this patient is low priority.\nPlease put them on the waitlist for when a medical provider becomes available.";
        } else if (Score < 328) {
            priorityMessage += "\nWe have determined this patient is medium priority.\nPlease assign an appropriate medical provider to their case" + "\n" + "and check back in with the patient's condition in a little while.";
        } else {
            priorityMessage += "\nWe have determined this patient is high priority,\nand it is advised to call an appropriate medical provider ASAP.";
        }

        System.out.println();
        System.out.println(priorityMessage);
    }

    public static boolean validZipCode(int val) {
        int firstDigit = val / 10000;
        if (firstDigit == 0 || firstDigit >= 10) {
            return false;
        }
        return true;
    }

    public static boolean validPainLevel(int val) {
        return val >= 1 && val <= 10;
    }

    public static void PrintStats(int patientCount, int maxScore) {
        System.out.println("Statistics for the day:");
        System.out.println("..." + patientCount + " patients were helped");
        System.out.println("...the highest priority patient we saw had a score of " + maxScore);
        System.out.println("Good job today!");
    }
}




